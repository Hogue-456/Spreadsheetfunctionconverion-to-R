Funktionsstartliste <- data.frame(Formel)
Funktionsstartliste$Nummer <- 1
Funktionsstartliste$Nummer <- cumsum(Funktionsstartliste$Nummer)
source('~/Tabellenkalkultionsumwandler/Argumentlistenschleife.R')