Ab <- 0
Bis <- 0
Fnct <- Bestandteile$Extrakt
Res <- 0
Nummer <- 0
Programm <- 0
Programm22 <- 0
Funktionsart <- Bestandteile$Funktionsart
Argumentliste <- data.frame(Ab, Bis, Fnct, Res, Nummer, Programm, Programm22, Funktionsart)