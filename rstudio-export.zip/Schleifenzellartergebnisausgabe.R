Funktionsart <- Funktionsliste$Funktionsart
Argumentliste$Funktionsart <- Funktionsart