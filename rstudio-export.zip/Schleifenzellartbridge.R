source('~/Tabellenkalkultionsumwandler/Stringteilausgabe mit Anfzeichenzahl.R', encoding = 'UTF-8')
source('~/Tabellenkalkultionsumwandler/Programmoutput225.R', encoding = 'UTF-8')