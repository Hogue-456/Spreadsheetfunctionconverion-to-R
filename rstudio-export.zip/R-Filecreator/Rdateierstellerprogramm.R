write.table(Proglist28, file = paste0('C:\\Users\\timh9\\Documents\\Tabellenkalkulationumwandler\\Programmausf�hrung\\Testprogramm20210728\\',Programmteil,'20210728.R'), append = FALSE, quote = FALSE, sep = " ",
            eol = "\n", na = "NA", dec = ",", row.names = FALSE,
            col.names = FALSE,
            fileEncoding = 'UTF-8')